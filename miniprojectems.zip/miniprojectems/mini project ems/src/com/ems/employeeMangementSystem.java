package com.ems;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class employeeMangementSystem {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			ArrayList<Employee> al=new ArrayList<>();
			Scanner scan=new Scanner(System.in);
			System.out.println("enter the detail if the Employee");
			char ch='Y';
			int id;
			String name;
			double salary,netSalary=1;
			String contact_no;
			String email_id;
			double providentFund=800;
			
			while(ch=='Y')
			{

				System.out.println("enter the id");
				id=scan.nextInt();
				System.out.println("enter the name");
				name=scan.next();
				System.out.println("enter the salary");
				salary=scan.nextDouble();
				System.out.println("enter the contact number");
				contact_no=scan.next();
				System.out.println("enter the email_id");
				email_id=scan.next();
				netSalary=salary-providentFund;


				Employee em=new Employee(id,name,salary,netSalary,contact_no,email_id);
				al.add(em);
				System.out.println("do u went enter more cadidate");
				System.out.println("enter Y for yes,N for No");
				ch=scan.next().charAt(0);
			}
			System.out.println(al);
			Collections.sort(al);
			System.out.println(al);
			
			
				System.out.println("\n*********Welcome to the Employee Management System**********\n");
				System.out.println("1). Add Employee to the DataBase\n" +
						"2). Search for Employee\n" +
						"3). Edit Employee details\n" +
						"4). Delete Employee Details\n" +
						"5). EXIT\n");
				System.out.println("Enter your choice : ");
				int chara = scan.nextInt();
				switch(chara)
				{
				case 1:
					System.out.println("\nEnter the following details to ADD list:\n");
					System.out.println("Enter ID :");
					id = scan.nextInt();
					System.out.println("Enter Name :");
					name = scan.next();
					System.out.println("Enter Salary :");
					salary = scan.nextDouble();
					System.out.println("Enter Contact No :");
					contact_no = scan.next();
					System.out.println("Enter Email-ID :");
					email_id = scan.next();
					al.add(new Employee(id, name, salary, netSalary, contact_no, email_id));
					System.out.println(al);
					break;
				case 2:
					System.out.println("Enter the Employee ID to search :");
					id = scan.nextInt();
					int i=0;
					for(Employee em: al)
					{
						if(id == em.id)
						{
							System.out.println(em+"\n");
							i++;
						}
					}
					if(i == 0)
					{
						System.out.println("\nEmployee Details are not available, Please enter a valid ID!!");
					}
					break;

				case 3: 
					System.out.println("\nEnter the Employee ID to EDIT the details");
				    id = scan.nextInt();
				    int j=0;
				    for(Employee em: al)
				    {
				    	if(id == em.id)
				    	{	
				    		j++;
				    		do{
							int ch1 =0;
							System.out.println("\nEDIT Employee Details :\n" +
									"1). Employee ID\n" +
									"2). Name\n" +
									"3). Salary\n" +
									"4). Contact No.\n" +
									"5). Email-ID\n" +
									"6). GO BACK\n");
							System.out.println("Enter your choice : ");
							ch1 = scan.nextInt();
							switch(ch1)
							{
							case 1:
								System.out.println("\nEnter new Employee ID:");
								em.id =scan.nextInt();
							    System.out.println(em+"\n");
							    break;

							case 2: 
								System.out.println("Enter new Employee Name:");
								em.name =scan.next();
							    System.out.println(em+"\n");
							    break;

							case 3:
								System.out.println("Enter new Employee Salary:");
								em.salary =scan.nextDouble();
							    System.out.println(em+"\n");
							    break;

							case 4: 
								System.out.println("Enter new Employee Contact No. :");
								em.contact_no =scan.next();
							    System.out.println(em+"\n");
							    break;

							case 5:
								System.out.println("Enter new Employee Email-ID :");
								em.email_id =scan.next();
							    System.out.println(em+"\n");
							    break;

							case 6: 
								j++;
								System.out.println(al);

							    break;

							default : 
								System.out.println("\nEnter a correct choice from the List :");
							    break;

							}
							
				    		}
					while(j==1);
				}
				}
				if(j == 0)
				{
					System.out.println("\nEmployee Details are not available, Please enter a valid ID!!");
				}break;
				case 4: 
					System.out.println("\nEnter Employee ID to DELETE from the Databse :");
					id = scan.nextInt();
					int k=0;
					try{
						for(Employee learner: al)
						{
							if(id == learner.id)
							{
								al.remove(learner);
								System.out.println(al);
								k++;
							}
						}
						if(k == 0)
						{
							System.out.println("\nEmployee Details are not available, Please enter a valid ID!!");
						}
					}
					catch(Exception ex){
						System.out.println(ex);
					}
					break;
			
					
				case 5:
					System.out.println("\nYou have chosen EXIT !! Saving Files and closing the tool.");


				}
				scan.close();


				
	}

	}








	class Employee implements Comparable<Employee>{
		int id;
		String name;
		double salary,netSalary;
		String contact_no;
		String email_id;
		
		
		public Employee(int id, String name, double salary, double netSalary, String contact_no, String email_id) {
			super();
			this.id = id;
			this.name = name;
			this.salary = salary;
			this.netSalary = netSalary;
			this.contact_no = contact_no;
			this.email_id = email_id;
		}
		@Override
		public int compareTo(Employee em) {
			if(salary==em.salary) {
				return 0;
			}
			else if(salary<em.salary) {
				return 1;
			}
			else {
				return -1;
			}
		}
		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", netSalary=" + netSalary
					+ ", contact_no=" + contact_no + ", email_id=" + email_id + "]";
		}

		
	}


	
	


